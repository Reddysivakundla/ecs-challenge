import { SearchFunctionPipe } from './search-function.pipe';

describe('SearchFunctionPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchFunctionPipe();
    expect(pipe).toBeTruthy();
  });
});
