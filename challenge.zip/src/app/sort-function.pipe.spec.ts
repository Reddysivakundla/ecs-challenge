import { SortFunctionPipe } from './sort-function.pipe';

describe('SortFunctionPipe', () => {
  it('create an instance', () => {
    const pipe = new SortFunctionPipe();
    expect(pipe).toBeTruthy();
  });
});
